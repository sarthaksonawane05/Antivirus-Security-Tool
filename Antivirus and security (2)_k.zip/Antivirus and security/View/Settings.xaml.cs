﻿using System;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Controls.Primitives;
using System.Windows.Media;
using System.Windows.Threading;

namespace Antivirus_and_security.View
{
    public partial class Settings : UserControl
    {
        // =========================================
        // VARIABLES
        // =========================================

        private DispatcherTimer settingsTimer;

        // =========================================
        // CONSTRUCTOR
        // =========================================

        public Settings()
        {
            InitializeComponent();

            StartSettingsMonitor();
        }

        // =========================================
        // TIMER
        // =========================================

        private void StartSettingsMonitor()
        {
            settingsTimer = new DispatcherTimer();

            settingsTimer.Interval =
                TimeSpan.FromSeconds(1);

            settingsTimer.Tick +=
                SettingsTimer_Tick;

            settingsTimer.Start();
        }

        // =========================================
        // TIMER EVENT
        // =========================================

        private void SettingsTimer_Tick(
            object sender,
            EventArgs e)
        {
            UpdateSystemStatus();
        }

        // =========================================
        // UPDATE STATUS
        // =========================================

        private void UpdateSystemStatus()
        {
            try
            {
                int enabledCount = 0;

                if (NotificationToggle.IsChecked == true)
                    enabledCount++;

                if (AutoScanToggle.IsChecked == true)
                    enabledCount++;

                if (ThemeToggle.IsChecked == true)
                    enabledCount++;

                if (UpdateToggle.IsChecked == true)
                    enabledCount++;

                double percent =
                    (enabledCount / 4.0) * 100;

                NotificationProgress.Value =
                    NotificationToggle.IsChecked == true
                    ? 100
                    : 20;

                UpdateProgress.Value =
                    UpdateToggle.IsChecked == true
                    ? 95
                    : 10;

                ThemeProgress.Value =
                    ThemeToggle.IsChecked == true
                    ? 98
                    : 15;

                if (enabledCount == 4)
                {
                    MainStatusText.Text =
                        "✔ Settings Applied";

                    MainStatusText.Foreground =
                        Brushes.Black;
                }
                else if (enabledCount >= 2)
                {
                    MainStatusText.Text =
                        "⚠ Partial Protection";

                    MainStatusText.Foreground =
                        Brushes.Orange;
                }
                else
                {
                    MainStatusText.Text =
                        "✖ Low Security";

                    MainStatusText.Foreground =
                        Brushes.Red;
                }
            }
            catch
            {
            }
        }

        // =========================================
        // NOTIFICATION TOGGLE
        // =========================================

        private void NotificationToggle_Checked(
            object sender,
            RoutedEventArgs e)
        {
            NotificationToggle.Content = "ON";

            NotificationStatusText.Text =
                "Alerts Enabled";

            MessageBox.Show(
                "Notifications Enabled");
        }

        private void NotificationToggle_Unchecked(
            object sender,
            RoutedEventArgs e)
        {
            NotificationToggle.Content = "OFF";

            NotificationStatusText.Text =
                "Alerts Disabled";

            MessageBox.Show(
                "Notifications Disabled");
        }

        // =========================================
        // AUTO SCAN TOGGLE
        // =========================================

        private void AutoScanToggle_Checked(
            object sender,
            RoutedEventArgs e)
        {
            AutoScanToggle.Content = "ON";

            AutoScanStatusText.Text =
                "Scheduled Daily";

            MessageBox.Show(
                "Auto Scan Enabled");
        }

        private void AutoScanToggle_Unchecked(
            object sender,
            RoutedEventArgs e)
        {
            AutoScanToggle.Content = "OFF";

            AutoScanStatusText.Text =
                "Auto Scan Disabled";

            MessageBox.Show(
                "Auto Scan Disabled");
        }

        // =========================================
        // THEME TOGGLE
        // =========================================

        private void ThemeToggle_Checked(
            object sender,
            RoutedEventArgs e)
        {
            ThemeToggle.Content = "ON";

            ThemeStatusText.Text =
                "Interface Enabled";

            MessageBox.Show(
                "Dark Theme Enabled");
        }

        private void ThemeToggle_Unchecked(
            object sender,
            RoutedEventArgs e)
        {
            ThemeToggle.Content = "OFF";

            ThemeStatusText.Text =
                "Light Theme Enabled";

            MessageBox.Show(
                "Dark Theme Disabled");
        }

        // =========================================
        // UPDATE TOGGLE
        // =========================================

        private void UpdateToggle_Checked(
            object sender,
            RoutedEventArgs e)
        {
            UpdateToggle.Content = "ON";

            UpdateStatusText.Text =
                "Always Updated";

            MessageBox.Show(
                "Auto Updates Enabled");
        }

        private void UpdateToggle_Unchecked(
            object sender,
            RoutedEventArgs e)
        {
            UpdateToggle.Content = "OFF";

            UpdateStatusText.Text =
                "Manual Updates";

            MessageBox.Show(
                "Auto Updates Disabled");
        }
    }
}