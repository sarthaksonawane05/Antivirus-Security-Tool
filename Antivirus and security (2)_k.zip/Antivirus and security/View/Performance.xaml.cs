﻿using System;
using System.Diagnostics;
using System.IO;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Media;
using System.Windows.Threading;

namespace Antivirus_and_security.View
{
    public partial class Performance : UserControl
    {
        // =========================================
        // VARIABLES
        // =========================================

        private DispatcherTimer performanceTimer;

        private PerformanceCounter cpuCounter;

        private Random random = new Random();

        // =========================================
        // CONSTRUCTOR
        // =========================================

        public Performance()
        {
            InitializeComponent();

            InitializePerformanceCounters();

            StartRealtimeMonitoring();
        }

        // =========================================
        // INITIALIZE PERFORMANCE COUNTERS
        // =========================================

        private void InitializePerformanceCounters()
        {
            try
            {
                cpuCounter = new PerformanceCounter(
                    "Processor",
                    "% Processor Time",
                    "_Total");

                cpuCounter.NextValue();
            }
            catch (Exception ex)
            {
                MessageBox.Show(
                    "Performance Counter Error\n\n"
                    + ex.Message);
            }
        }

        // =========================================
        // START TIMER
        // =========================================

        private void StartRealtimeMonitoring()
        {
            performanceTimer = new DispatcherTimer();

            performanceTimer.Interval =
                TimeSpan.FromSeconds(1);

            performanceTimer.Tick +=
                PerformanceTimer_Tick;

            performanceTimer.Start();
        }

        // =========================================
        // TIMER EVENT
        // =========================================

        private void PerformanceTimer_Tick(
            object sender,
            EventArgs e)
        {
            UpdateMemoryUsage();

            UpdateCpuUsage();

            UpdateDiskUsage();

            UpdateClock();

            UpdateSystemStatus();
        }

        // =========================================
        // MEMORY USAGE
        // =========================================

        private void UpdateMemoryUsage()
        {
            try
            {
                Process currentProcess =
                    Process.GetCurrentProcess();

                double usedMemory =
                    currentProcess.WorkingSet64;

                double totalMemory =
                    8L * 1024 * 1024 * 1024;

                double memoryPercent =
                    (usedMemory / totalMemory) * 100;

                if (memoryPercent < 0)
                    memoryPercent = 0;

                if (memoryPercent > 100)
                    memoryPercent = 100;

                MemoryProgress.Value =
                    memoryPercent;

                MemoryValueText.Text =
                    ((int)memoryPercent).ToString()
                    + "%";

                RamInfoText.Text =
                    "RAM : "
                    + ((int)(usedMemory / 1024 / 1024))
                    + " MB Used";
            }
            catch
            {
            }
        }

        // =========================================
        // CPU USAGE
        // =========================================

        private void UpdateCpuUsage()
        {
            try
            {
                float cpu =
                    cpuCounter.NextValue();

                if (cpu < 0)
                    cpu = 0;

                if (cpu > 100)
                    cpu = 100;

                CpuProgress.Value =
                    cpu;

                CpuValueText.Text =
                    ((int)cpu).ToString()
                    + "%";

                CpuInfoText.Text =
                    "CPU : "
                    + ((int)cpu).ToString()
                    + "%";
            }
            catch
            {
            }
        }

        // =========================================
        // DISK USAGE
        // =========================================

        private void UpdateDiskUsage()
        {
            try
            {
                DriveInfo drive =
                    new DriveInfo("C");

                if (drive.IsReady)
                {
                    double total =
                        drive.TotalSize;

                    double free =
                        drive.TotalFreeSpace;

                    double used =
                        total - free;

                    double percent =
                        (used / total) * 100;

                    if (percent < 0)
                        percent = 0;

                    if (percent > 100)
                        percent = 100;

                    DiskProgress.Value =
                        percent;

                    DiskValueText.Text =
                        ((int)percent).ToString()
                        + "%";

                    DiskInfoText.Text =
                        "Disk : "
                        + ((int)(free / 1024 / 1024 / 1024))
                        + " GB Free";
                }
            }
            catch
            {
            }
        }

        // =========================================
        // CLOCK
        // =========================================

        private void UpdateClock()
        {
            TimeInfoText.Text =
                DateTime.Now.ToString(
                    "dddd, dd MMM yyyy hh:mm:ss tt");
        }

        // =========================================
        // SYSTEM STATUS
        // =========================================

        private void UpdateSystemStatus()
        {
            try
            {
                double cpu =
                    CpuProgress.Value;

                if (cpu > 85)
                {
                    SystemOptimizeText.Text =
                        "⚠ High CPU Usage";

                    SystemOptimizeText.Foreground =
                        Brushes.Red;

                    OptimizeStatusText.Text =
                        "WARNING";
                }
                else
                {
                    SystemOptimizeText.Text =
                        "✔ System Optimized";

                    SystemOptimizeText.Foreground =
                        Brushes.Black;

                    OptimizeStatusText.Text =
                        "OPTIMIZED";
                }
            }
            catch
            {
            }
        }

        // =========================================
        // BOOST RAM BUTTON
        // =========================================

        private async void BoostRamButton_Click(
            object sender,
            RoutedEventArgs e)
        {
            try
            {
                BoostRamButton.IsEnabled = false;

                BoostRamButton.Content =
                    "BOOSTING...";

                RamStatusText.Text =
                    "Cleaning Memory";

                await Task.Delay(3000);

                GC.Collect();

                GC.WaitForPendingFinalizers();

                RamStatusText.Text =
                    "RAM Optimized";

                MessageBox.Show(
                    "Memory optimization completed.");

                BoostRamButton.Content =
                    "Boost";

                BoostRamButton.IsEnabled = true;
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        // =========================================
        // CPU OPTIMIZER BUTTON
        // =========================================

        private async void OptimizeCpuButton_Click(
            object sender,
            RoutedEventArgs e)
        {
            try
            {
                OptimizeCpuButton.IsEnabled = false;

                OptimizeCpuButton.Content =
                    "OPTIMIZING...";

                CpuStatusText.Text =
                    "Balancing CPU";

                await Task.Delay(3000);

                CpuStatusText.Text =
                    "Balanced Usage";

                MessageBox.Show(
                    "CPU optimization completed.");

                OptimizeCpuButton.Content =
                    "Optimize";

                OptimizeCpuButton.IsEnabled = true;
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        // =========================================
        // DISK CLEANUP BUTTON
        // =========================================

        private async void DiskCleanupButton_Click(
            object sender,
            RoutedEventArgs e)
        {
            try
            {
                DiskCleanupButton.IsEnabled = false;

                DiskCleanupButton.Content =
                    "CLEANING...";

                DiskStatusText.Text =
                    "Removing Temp Files";

                await Task.Delay(3000);

                string tempPath =
                    Path.GetTempPath();

                string[] tempFiles =
                    Directory.GetFiles(tempPath);

                foreach (string file in tempFiles)
                {
                    try
                    {
                        File.Delete(file);
                    }
                    catch
                    {
                    }
                }

                DiskStatusText.Text =
                    "Storage Freed";

                MessageBox.Show(
                    "Temporary files cleaned.");

                DiskCleanupButton.Content =
                    "Clean";

                DiskCleanupButton.IsEnabled = true;
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        // =========================================
        // STARTUP BUTTON
        // =========================================

        private void StartupButton_Click(
            object sender,
            RoutedEventArgs e)
        {
            try
            {
                Process.Start("msconfig");

                StartupStatusText.Text =
                    "Startup Opened";
            }
            catch (Exception ex)
            {
                MessageBox.Show(
                    "Unable to open startup manager.\n\n"
                    + ex.Message);
            }
        }
    }
}