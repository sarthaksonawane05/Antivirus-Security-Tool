﻿using System;
using System.Diagnostics;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Media;
using System.Windows.Threading;

namespace Antivirus_and_security.View
{
    public partial class Protection : UserControl
    {
        // =========================================
        // VARIABLES
        // =========================================

        private DispatcherTimer protectionTimer;

        private Random random;

        // =========================================
        // CONSTRUCTOR
        // =========================================

        public Protection()
        {
            InitializeComponent();

            random = new Random();

            StartRealtimeProtection();
        }

        // =========================================
        // START TIMER
        // =========================================

        private void StartRealtimeProtection()
        {
            protectionTimer = new DispatcherTimer();

            protectionTimer.Interval =
                TimeSpan.FromSeconds(1);

            protectionTimer.Tick +=
                ProtectionTimer_Tick;

            protectionTimer.Start();
        }

        // =========================================
        // TIMER EVENT
        // =========================================

        private void ProtectionTimer_Tick(
            object sender,
            EventArgs e)
        {
            UpdateProtectionStatus();
        }

        // =========================================
        // UPDATE LIVE STATUS
        // =========================================

        private void UpdateProtectionStatus()
        {
            try
            {
                int threat =
                    random.Next(95, 100);

                int firewall =
                    random.Next(93, 100);

                int shield =
                    100;

                ThreatProgress.Value =
                    threat;

                FirewallProgress.Value =
                    firewall;

                ShieldProgress.Value =
                    shield;

                ThreatValueText.Text =
                    threat.ToString() + "%";

                FirewallValueText.Text =
                    firewall.ToString() + "%";

                ShieldValueText.Text =
                    shield.ToString() + "%";

                if (threat < 96)
                {
                    MainProtectionText.Text =
                        "⚠ Minor Threat Detected";

                    MainProtectionText.Foreground =
                        Brushes.Red;
                }
                else
                {
                    MainProtectionText.Text =
                        "✔ Fully Protected";

                    MainProtectionText.Foreground =
                        Brushes.Black;
                }
            }
            catch
            {
            }
        }

        // =========================================
        // REALTIME DEFENSE
        // =========================================

        private async void RealTimeButton_Click(
            object sender,
            RoutedEventArgs e)
        {
            try
            {
                RealTimeButton.IsEnabled = false;

                RealTimeButton.Content =
                    "LOADING...";

                RealTimeStatusText.Text =
                    "Checking Protection";

                await Task.Delay(2000);

                Process.Start(
                    "windowsdefender:");

                RealTimeStatusText.Text =
                    "Always Active";

                MessageBox.Show(
                    "Windows Defender Opened.");

                RealTimeButton.Content =
                    "Manage";

                RealTimeButton.IsEnabled = true;
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);

                RealTimeButton.Content =
                    "Manage";

                RealTimeButton.IsEnabled = true;
            }
        }

        // =========================================
        // FIREWALL
        // =========================================

        private async void FirewallButton_Click(
            object sender,
            RoutedEventArgs e)
        {
            try
            {
                FirewallButton.IsEnabled = false;

                FirewallButton.Content =
                    "OPENING...";

                FirewallStatusText.Text =
                    "Checking Firewall";

                await Task.Delay(2000);

                Process.Start(
                    "control.exe",
                    "/name Microsoft.WindowsFirewall");

                FirewallStatusText.Text =
                    "Network Protected";

                MessageBox.Show(
                    "Firewall Opened.");

                FirewallButton.Content =
                    "Manage";

                FirewallButton.IsEnabled = true;
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);

                FirewallButton.Content =
                    "Manage";

                FirewallButton.IsEnabled = true;
            }
        }

        // =========================================
        // MALWARE SCAN
        // =========================================

        private async void MalwareButton_Click(
            object sender,
            RoutedEventArgs e)
        {
            try
            {
                MalwareButton.IsEnabled = false;

                MalwareButton.Content =
                    "SCANNING...";

                MalwareStatusText.Text =
                    "Scanning System";

                for (int i = 0; i <= 100; i++)
                {
                    ThreatProgress.Value = i;

                    ThreatValueText.Text =
                        i.ToString() + "%";

                    await Task.Delay(40);
                }

                MalwareStatusText.Text =
                    "No Threat Found";

                ThreatProgress.Value = 98;

                ThreatValueText.Text = "98%";

                MessageBox.Show(
                    "System scan completed.\nNo malware detected.");

                MalwareButton.Content =
                    "Scan Now";

                MalwareButton.IsEnabled = true;
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);

                MalwareButton.Content =
                    "Scan Now";

                MalwareButton.IsEnabled = true;
            }
        }

        // =========================================
        // WEB PROTECTION
        // =========================================

        private async void WebButton_Click(
            object sender,
            RoutedEventArgs e)
        {
            try
            {
                WebButton.IsEnabled = false;

                WebButton.Content =
                    "CHECKING...";

                WebStatusText.Text =
                    "Checking Browser Security";

                await Task.Delay(2000);

                WebStatusText.Text =
                    "Safe Browsing";

                MessageBox.Show(
                    "Web protection is active.");

                WebButton.Content =
                    "Manage";

                WebButton.IsEnabled = true;
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);

                WebButton.Content =
                    "Manage";

                WebButton.IsEnabled = true;
            }
        }
    }
}