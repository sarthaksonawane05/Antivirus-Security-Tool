﻿using System;
using System.Diagnostics;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Media;
using System.Windows.Threading;

namespace Antivirus_and_security.View
{
    public partial class Privacy : UserControl
    {
        // =========================================
        // VARIABLES
        // =========================================

        private DispatcherTimer privacyTimer;

        private Random random;

        // =========================================
        // CONSTRUCTOR
        // =========================================

        public Privacy()
        {
            InitializeComponent();

            random = new Random();

            StartRealtimeMonitoring();
        }

        // =========================================
        // TIMER
        // =========================================

        private void StartRealtimeMonitoring()
        {
            privacyTimer = new DispatcherTimer();

            privacyTimer.Interval =
                TimeSpan.FromSeconds(1);

            privacyTimer.Tick +=
                PrivacyTimer_Tick;

            privacyTimer.Start();
        }

        // =========================================
        // TIMER EVENT
        // =========================================

        private void PrivacyTimer_Tick(
            object sender,
            EventArgs e)
        {
            UpdatePrivacyMetrics();

            UpdateClock();

            UpdateProtectionStatus();
        }

        // =========================================
        // UPDATE METRICS
        // =========================================

        private void UpdatePrivacyMetrics()
        {
            try
            {
                int threat =
                    random.Next(88, 100);

                int vpn =
                    random.Next(95, 100);

                int leak =
                    random.Next(80, 100);

                ThreatProgress.Value =
                    threat;

                ThreatValueText.Text =
                    threat.ToString() + "%";

                VpnProgress.Value =
                    vpn;

                VpnValueText.Text =
                    vpn.ToString() + "%";

                LeakProgress.Value =
                    leak;

                LeakValueText.Text =
                    leak.ToString() + "%";
            }
            catch
            {
            }
        }

        // =========================================
        // CLOCK
        // =========================================

        private void UpdateClock()
        {
            PrivacyTimeText.Text =
                DateTime.Now.ToString(
                    "dddd, dd MMM yyyy hh:mm:ss tt");
        }

        // =========================================
        // STATUS
        // =========================================

        private void UpdateProtectionStatus()
        {
            try
            {
                if (LeakProgress.Value < 85)
                {
                    ProtectionStatusText.Text =
                        "⚠ Privacy Warning";

                    ProtectionStatusText.Foreground =
                        Brushes.Red;

                    PrivacyMainStatusText.Text =
                        "WARNING";
                }
                else
                {
                    ProtectionStatusText.Text =
                        "✔ Fully Protected";

                    ProtectionStatusText.Foreground =
                        Brushes.Black;

                    PrivacyMainStatusText.Text =
                        "ACTIVE";
                }
            }
            catch
            {
            }
        }

        // =========================================
        // VPN
        // =========================================

        private async void VpnButton_Click(
            object sender,
            RoutedEventArgs e)
        {
            try
            {
                VpnButton.IsEnabled = false;

                VpnButton.Content =
                    "CONNECTING...";

                VpnStatusText.Text =
                    "Establishing VPN";

                await Task.Delay(3000);

                VpnStatusText.Text =
                    "Encrypted Connection";

                VpnInfoText.Text =
                    "VPN : Connected";

                MessageBox.Show(
                    "VPN protection enabled.");

                VpnButton.Content =
                    "Manage";

                VpnButton.IsEnabled = true;
            }
            catch
            {
            }
        }

        // =========================================
        // CAMERA
        // =========================================

        private async void CameraButton_Click(
            object sender,
            RoutedEventArgs e)
        {
            try
            {
                CameraButton.IsEnabled = false;

                CameraButton.Content =
                    "PROTECTING...";

                CameraStatusText.Text =
                    "Securing Camera";

                await Task.Delay(3000);

                CameraStatusText.Text =
                    "Access Protection";

                CameraInfoText.Text =
                    "Camera : Protected";

                MessageBox.Show(
                    "Camera protection enabled.");

                CameraButton.Content =
                    "Manage";

                CameraButton.IsEnabled = true;
            }
            catch
            {
            }
        }

        // =========================================
        // PASSWORD
        // =========================================

        private async void PasswordButton_Click(
            object sender,
            RoutedEventArgs e)
        {
            try
            {
                PasswordButton.IsEnabled = false;

                PasswordButton.Content =
                    "VERIFYING...";

                PasswordStatusText.Text =
                    "Encrypting Credentials";

                await Task.Delay(3000);

                PasswordStatusText.Text =
                    "Credentials Secured";

                MessageBox.Show(
                    "Password vault secured.");

                PasswordButton.Content =
                    "Manage";

                PasswordButton.IsEnabled = true;
            }
            catch
            {
            }
        }

        // =========================================
        // IDENTITY
        // =========================================

        private async void IdentityButton_Click(
            object sender,
            RoutedEventArgs e)
        {
            try
            {
                IdentityButton.IsEnabled = false;

                IdentityButton.Content =
                    "SCANNING...";

                IdentityStatusText.Text =
                    "Monitoring Identity";

                await Task.Delay(3000);

                IdentityStatusText.Text =
                    "Leak Monitoring";

                IdentityInfoText.Text =
                    "Identity : Secure";

                MessageBox.Show(
                    "No identity leaks detected.");

                IdentityButton.Content =
                    "Manage";

                IdentityButton.IsEnabled = true;
            }
            catch
            {
            }
        }
    }
}