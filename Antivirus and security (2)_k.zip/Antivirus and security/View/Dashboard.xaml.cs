﻿using System;
using System.Diagnostics;
using System.IO;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Media;
using System.Windows.Threading;

namespace Antivirus_and_security.View
{
    public partial class Dashboard : UserControl
    {
        // =========================================
        // VARIABLES
        // =========================================

        private DispatcherTimer dashboardTimer;

        private PerformanceCounter cpuCounter;
        private PerformanceCounter ramCounter;

        private Random random;

        // =========================================
        // CONSTRUCTOR
        // =========================================

        public Dashboard()
        {
            InitializeComponent();

            random = new Random();

            InitializePerformanceCounters();

            StartRealtimeMonitoring();
        }

        // =========================================
        // PERFORMANCE COUNTERS
        // =========================================

        private void InitializePerformanceCounters()
        {
            try
            {
                cpuCounter = new PerformanceCounter(
                    "Processor",
                    "% Processor Time",
                    "_Total");

                ramCounter = new PerformanceCounter(
                    "Memory",
                    "% Committed Bytes In Use");

                cpuCounter.NextValue();
                ramCounter.NextValue();
            }
            catch (Exception ex)
            {
                MessageBox.Show(
                    "Performance Counter Error:\n\n"
                    + ex.Message);
            }
        }

        // =========================================
        // START MONITORING
        // =========================================

        private void StartRealtimeMonitoring()
        {
            dashboardTimer = new DispatcherTimer();

            dashboardTimer.Interval =
                TimeSpan.FromSeconds(1);

            dashboardTimer.Tick += DashboardTimer_Tick;

            dashboardTimer.Start();
        }

        // =========================================
        // TIMER EVENT
        // =========================================

        private void DashboardTimer_Tick(
            object sender,
            EventArgs e)
        {
            UpdateCpuUsage();

            UpdateRamUsage();

            UpdateDiskUsage();

            UpdateFirewallStatus();

            UpdateSystemClock();

            UpdatePerformanceStatus();
        }

        // =========================================
        // CPU
        // =========================================

        private void UpdateCpuUsage()
        {
            try
            {
                float cpuValue =
                    cpuCounter.NextValue();

                if (cpuValue < 0)
                    cpuValue = 0;

                if (cpuValue > 100)
                    cpuValue = 100;

                CpuProgress.Value = cpuValue;

                CpuValueText.Text =
                    "CPU Usage : "
                    + ((int)cpuValue).ToString()
                    + "%";

                if (cpuValue > 85)
                {
                    CpuValueText.Foreground =
                        Brushes.Red;
                }
                else if (cpuValue > 60)
                {
                    CpuValueText.Foreground =
                        Brushes.Orange;
                }
                else
                {
                    CpuValueText.Foreground =
                        Brushes.Lime;
                }
            }
            catch
            {
            }
        }

        // =========================================
        // RAM
        // =========================================

        private void UpdateRamUsage()
        {
            try
            {
                float ramValue =
                    ramCounter.NextValue();

                if (ramValue < 0)
                    ramValue = 0;

                if (ramValue > 100)
                    ramValue = 100;

                RamUsageText.Text =
                    "RAM Usage : "
                    + ((int)ramValue).ToString()
                    + "%";
            }
            catch
            {
            }
        }

        // =========================================
        // DISK
        // =========================================

        private void UpdateDiskUsage()
        {
            try
            {
                DriveInfo drive =
                    new DriveInfo("C");

                if (drive.IsReady)
                {
                    double total =
                        drive.TotalSize;

                    double free =
                        drive.TotalFreeSpace;

                    double used =
                        total - free;

                    double percent =
                        (used / total) * 100;

                    DiskUsageText.Text =
                        "Disk Usage : "
                        + ((int)percent).ToString()
                        + "%";
                }
            }
            catch
            {
            }
        }

        // =========================================
        // CLOCK
        // =========================================

        private void UpdateSystemClock()
        {
            SystemTimeText.Text =
                DateTime.Now.ToString(
                    "dddd, dd MMM yyyy  hh:mm:ss tt");
        }

        // =========================================
        // FIREWALL
        // =========================================

        private void UpdateFirewallStatus()
        {
            FirewallProgress.Value = 100;

            FirewallValueText.Text =
                "Firewall Enabled";

            FirewallValueText.Foreground =
                Brushes.Lime;
        }

        // =========================================
        // PERFORMANCE STATUS
        // =========================================

        private void UpdatePerformanceStatus()
        {
            try
            {
                double cpu =
                    CpuProgress.Value;

                if (cpu > 90)
                {
                    PerformanceStatusText.Text =
                        "Critical";

                    PerformanceStatusText.Foreground =
                        Brushes.Red;
                }
                else if (cpu > 70)
                {
                    PerformanceStatusText.Text =
                        "High Usage";

                    PerformanceStatusText.Foreground =
                        Brushes.Orange;
                }
                else
                {
                    PerformanceStatusText.Text =
                        "Optimized";

                    PerformanceStatusText.Foreground =
                        Brushes.Lime;
                }
            }
            catch
            {
            }
        }

        // =========================================
        // SCAN BUTTON
        // =========================================

        private async void StartScanButton_Click(
            object sender,
            RoutedEventArgs e)
        {
            try
            {
                StartScanButton.IsEnabled = false;

                StartScanButton.Content =
                    "SCANNING...";

                ScanProgress.Value = 0;

                ScanStatusText.Text =
                    "Initializing scan...";

                SystemStatusText.Text =
                    "Scanning System";

                ThreatCountText.Text =
                    "Checking files...";

                ThreatCountText.Foreground =
                    Brushes.Orange;

                int threats = 0;

                for (int i = 0; i <= 100; i++)
                {
                    ScanProgress.Value = i;

                    ScanStatusText.Text =
                        "Scanning : "
                        + i.ToString()
                        + "%";

                    await Task.Delay(60);

                    if (random.Next(0, 300) == 10)
                    {
                        threats++;
                    }
                }

                // SAFE RESULT

                if (threats == 0)
                {
                    SystemStatusText.Text =
                        "System Fully Secure";

                    ThreatCountText.Text =
                        "No threats detected";

                    ThreatCountText.Foreground =
                        Brushes.Lime;

                    ProtectionButton.Content =
                        "PROTECTED";

                    ProtectionButton.Foreground =
                        Brushes.Black;

                    ThreatStatusText.Text =
                        "Active";

                    ThreatStatusText.Foreground =
                        Brushes.Lime;
                }
                else
                {
                    SystemStatusText.Text =
                        "Threats Detected";

                    ThreatCountText.Text =
                        threats.ToString()
                        + " suspicious files found";

                    ThreatCountText.Foreground =
                        Brushes.Red;

                    ProtectionButton.Content =
                        "WARNING";

                    ProtectionButton.Foreground =
                        Brushes.Red;

                    ThreatStatusText.Text =
                        "Threat Found";

                    ThreatStatusText.Foreground =
                        Brushes.Red;
                }

                ScanStatusText.Text =
                    "Quick scan completed";

                LastScanText.Text =
                    "Last Scan : "
                    + DateTime.Now.ToString(
                        "hh:mm:ss tt");

                StartScanButton.IsEnabled = true;

                StartScanButton.Content =
                    "START QUICK SCAN";
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);

                StartScanButton.IsEnabled = true;

                StartScanButton.Content =
                    "START QUICK SCAN";
            }
        }

        // =========================================
        // PROTECTION BUTTON
        // =========================================

        private void ProtectionButton_Click(
            object sender,
            RoutedEventArgs e)
        {
            MessageBox.Show(
                "Real-Time Protection is Active",
                "Cyber Defender",
                MessageBoxButton.OK,
                MessageBoxImage.Information);
        }
    }
}